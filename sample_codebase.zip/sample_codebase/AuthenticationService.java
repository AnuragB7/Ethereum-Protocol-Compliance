package com.example.service;

import com.example.auth.User;
import com.example.dao.UserDAO;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Service class for handling user authentication
 */
public class AuthenticationService {
    private UserDAO userDAO;
    private static final int MAX_LOGIN_ATTEMPTS = 3;
    
    public AuthenticationService() {
        this.userDAO = new UserDAO();
    }
    
    /**
     * Register a new user
     */
    public boolean registerUser(String username, String email, String password, String role) {
        // Validate inputs
        if (!validateUsername(username)) {
            System.err.println("Invalid username format");
            return false;
        }
        
        if (!validateEmail(email)) {
            System.err.println("Invalid email format");
            return false;
        }
        
        if (!validatePassword(password)) {
            System.err.println("Password does not meet requirements");
            return false;
        }
        
        // Check if user already exists
        if (userDAO.findByUsername(username) != null) {
            System.err.println("Username already exists");
            return false;
        }
        
        if (userDAO.findByEmail(email) != null) {
            System.err.println("Email already registered");
            return false;
        }
        
        // Hash password
        String passwordHash = hashPassword(password);
        
        // Create user
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPasswordHash(passwordHash);
        user.setRole(role);
        user.setActive(true);
        
        return userDAO.createUser(user);
    }
    
    /**
     * Authenticate user login
     */
    public User login(String username, String password) {
        // Find user
        User user = userDAO.findByUsername(username);
        
        if (user == null) {
            System.err.println("User not found");
            return null;
        }
        
        // Check if user is active
        if (!user.isActive()) {
            System.err.println("User account is deactivated");
            return null;
        }
        
        // Verify password
        if (verifyPassword(password, user.getPasswordHash())) {
            System.out.println("Login successful for user: " + username);
            logLoginAttempt(username, true);
            return user;
        } else {
            System.err.println("Invalid password");
            logLoginAttempt(username, false);
            return null;
        }
    }
    
    /**
     * Change user password
     */
    public boolean changePassword(String username, String oldPassword, String newPassword) {
        User user = login(username, oldPassword);
        
        if (user == null) {
            return false;
        }
        
        if (!validatePassword(newPassword)) {
            System.err.println("New password does not meet requirements");
            return false;
        }
        
        String newPasswordHash = hashPassword(newPassword);
        user.setPasswordHash(newPasswordHash);
        
        return userDAO.updateUser(user);
    }
    
    /**
     * Reset password (admin function)
     */
    public boolean resetPassword(String username, String newPassword) {
        User user = userDAO.findByUsername(username);
        
        if (user == null) {
            return false;
        }
        
        String newPasswordHash = hashPassword(newPassword);
        user.setPasswordHash(newPasswordHash);
        
        return userDAO.updateUser(user);
    }
    
    /**
     * Hash password using SHA-256
     */
    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hashedBytes);
        } catch (NoSuchAlgorithmException e) {
            System.err.println("Error hashing password: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Verify password against hash
     */
    private boolean verifyPassword(String password, String hash) {
        String hashedPassword = hashPassword(password);
        return hashedPassword != null && hashedPassword.equals(hash);
    }
    
    /**
     * Validate username format
     */
    private boolean validateUsername(String username) {
        return username != null && 
               username.length() >= 3 && 
               username.length() <= 50 &&
               username.matches("^[a-zA-Z0-9_]+$");
    }
    
    /**
     * Validate email format
     */
    private boolean validateEmail(String email) {
        return email != null && 
               email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }
    
    /**
     * Validate password requirements
     */
    private boolean validatePassword(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
        
        boolean hasUpperCase = password.matches(".*[A-Z].*");
        boolean hasLowerCase = password.matches(".*[a-z].*");
        boolean hasDigit = password.matches(".*\\d.*");
        boolean hasSpecialChar = password.matches(".*[!@#$%^&*()].*");
        
        return hasUpperCase && hasLowerCase && hasDigit && hasSpecialChar;
    }
    
    /**
     * Log login attempt
     */
    private void logLoginAttempt(String username, boolean success) {
        String status = success ? "SUCCESS" : "FAILED";
        System.out.println("Login attempt - Username: " + username + " Status: " + status);
    }
    
    /**
     * Check user permissions
     */
    public boolean hasPermission(User user, String requiredRole) {
        if (user == null || !user.isActive()) {
            return false;
        }
        
        return user.getRole().equalsIgnoreCase(requiredRole) || 
               user.getRole().equalsIgnoreCase("ADMIN");
    }
}

