package com.example.database;

import java.sql.*;
import java.util.Properties;

/**
 * Database connection manager using singleton pattern
 */
public class DatabaseManager {
    private static DatabaseManager instance;
    private Connection connection;
    private String url;
    private String username;
    private String password;
    
    private DatabaseManager() {
        try {
            // Load configuration
            this.url = "jdbc:mysql://localhost:3306/userdb";
            this.username = "admin";
            this.password = "admin123";
            
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found: " + e.getMessage());
        }
    }
    
    /**
     * Get singleton instance of DatabaseManager
     */
    public static DatabaseManager getInstance() {
        if (instance == null) {
            synchronized (DatabaseManager.class) {
                if (instance == null) {
                    instance = new DatabaseManager();
                }
            }
        }
        return instance;
    }
    
    /**
     * Get database connection
     */
    public Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Database connection established");
        }
        return connection;
    }
    
    /**
     * Execute a SELECT query and return ResultSet
     */
    public ResultSet executeQuery(String query) throws SQLException {
        Connection conn = getConnection();
        Statement stmt = conn.createStatement();
        return stmt.executeQuery(query);
    }
    
    /**
     * Execute an UPDATE, INSERT, or DELETE query
     */
    public int executeUpdate(String query) throws SQLException {
        Connection conn = getConnection();
        Statement stmt = conn.createStatement();
        return stmt.executeUpdate(query);
    }
    
    /**
     * Execute a prepared statement query
     */
    public PreparedStatement prepareStatement(String query) throws SQLException {
        Connection conn = getConnection();
        return conn.prepareStatement(query);
    }
    
    /**
     * Close database connection
     */
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database connection closed");
            }
        } catch (SQLException e) {
            System.err.println("Error closing connection: " + e.getMessage());
        }
    }
    
    /**
     * Test database connectivity
     */
    public boolean testConnection() {
        try {
            Connection conn = getConnection();
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            System.err.println("Connection test failed: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Initialize database schema
     */
    public void initializeDatabase() throws SQLException {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS users (" +
                "user_id INT PRIMARY KEY AUTO_INCREMENT, " +
                "username VARCHAR(50) UNIQUE NOT NULL, " +
                "email VARCHAR(100) UNIQUE NOT NULL, " +
                "password_hash VARCHAR(255) NOT NULL, " +
                "role VARCHAR(20) NOT NULL, " +
                "is_active BOOLEAN DEFAULT true, " +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
        
        executeUpdate(createTableSQL);
        System.out.println("Database schema initialized");
    }
}
