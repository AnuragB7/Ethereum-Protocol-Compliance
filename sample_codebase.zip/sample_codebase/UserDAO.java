package com.example.dao;

import com.example.auth.User;
import com.example.database.DatabaseManager;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for User entity
 */
public class UserDAO {
    private DatabaseManager dbManager;
    
    public UserDAO() {
        this.dbManager = DatabaseManager.getInstance();
    }
    
    /**
     * Create a new user in the database
     */
    public boolean createUser(User user) {
        String query = "INSERT INTO users (username, email, password_hash, role, is_active) " +
                      "VALUES (?, ?, ?, ?, ?)";
        
        try {
            PreparedStatement pstmt = dbManager.prepareStatement(query);
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getEmail());
            pstmt.setString(3, user.getPasswordHash());
            pstmt.setString(4, user.getRole());
            pstmt.setBoolean(5, user.isActive());
            
            int rowsAffected = pstmt.executeUpdate();
            pstmt.close();
            
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error creating user: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Find user by username
     */
    public User findByUsername(String username) {
        String query = "SELECT * FROM users WHERE username = ?";
        
        try {
            PreparedStatement pstmt = dbManager.prepareStatement(query);
            pstmt.setString(1, username);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                User user = extractUserFromResultSet(rs);
                rs.close();
                pstmt.close();
                return user;
            }
            
            rs.close();
            pstmt.close();
        } catch (SQLException e) {
            System.err.println("Error finding user: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Find user by email
     */
    public User findByEmail(String email) {
        String query = "SELECT * FROM users WHERE email = ?";
        
        try {
            PreparedStatement pstmt = dbManager.prepareStatement(query);
            pstmt.setString(1, email);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                User user = extractUserFromResultSet(rs);
                rs.close();
                pstmt.close();
                return user;
            }
            
            rs.close();
            pstmt.close();
        } catch (SQLException e) {
            System.err.println("Error finding user by email: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Get all users
     */
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM users";
        
        try {
            ResultSet rs = dbManager.executeQuery(query);
            
            while (rs.next()) {
                users.add(extractUserFromResultSet(rs));
            }
            
            rs.close();
        } catch (SQLException e) {
            System.err.println("Error getting all users: " + e.getMessage());
        }
        
        return users;
    }
    
    /**
     * Update user information
     */
    public boolean updateUser(User user) {
        String query = "UPDATE users SET email = ?, password_hash = ?, role = ?, is_active = ? " +
                      "WHERE user_id = ?";
        
        try {
            PreparedStatement pstmt = dbManager.prepareStatement(query);
            pstmt.setString(1, user.getEmail());
            pstmt.setString(2, user.getPasswordHash());
            pstmt.setString(3, user.getRole());
            pstmt.setBoolean(4, user.isActive());
            pstmt.setInt(5, user.getUserId());
            
            int rowsAffected = pstmt.executeUpdate();
            pstmt.close();
            
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error updating user: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Delete user by ID
     */
    public boolean deleteUser(int userId) {
        String query = "DELETE FROM users WHERE user_id = ?";
        
        try {
            PreparedStatement pstmt = dbManager.prepareStatement(query);
            pstmt.setInt(1, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            pstmt.close();
            
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting user: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Deactivate user instead of deleting
     */
    public boolean deactivateUser(int userId) {
        String query = "UPDATE users SET is_active = false WHERE user_id = ?";
        
        try {
            PreparedStatement pstmt = dbManager.prepareStatement(query);
            pstmt.setInt(1, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            pstmt.close();
            
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error deactivating user: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Extract User object from ResultSet
     */
    private User extractUserFromResultSet(ResultSet rs) throws SQLException {
        User user = new User();
        user.setUserId(rs.getInt("user_id"));
        user.setUsername(rs.getString("username"));
        user.setEmail(rs.getString("email"));
        user.setPasswordHash(rs.getString("password_hash"));
        user.setRole(rs.getString("role"));
        user.setActive(rs.getBoolean("is_active"));
        return user;
    }
}

