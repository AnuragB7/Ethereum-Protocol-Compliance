package com.example.controller;

import com.example.auth.User;
import com.example.service.AuthenticationService;

import java.util.Scanner;

/**
 * Controller class for handling login UI and user interactions
 */
public class LoginController {
    private AuthenticationService authService;
    private User currentUser;
    private Scanner scanner;
    
    public LoginController() {
        this.authService = new AuthenticationService();
        this.scanner = new Scanner(System.in);
        this.currentUser = null;
    }
    
    /**
     * Main menu for login system
     */
    public void showMainMenu() {
        while (true) {
            System.out.println("\n===== User Authentication System =====");
            System.out.println("1. Login");
            System.out.println("2. Register");
            System.out.println("3. Exit");
            System.out.print("Select an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline
            
            switch (choice) {
                case 1:
                    handleLogin();
                    break;
                case 2:
                    handleRegistration();
                    break;
                case 3:
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
    
    /**
     * Handle user login
     */
    private void handleLogin() {
        System.out.print("Username: ");
        String username = scanner.nextLine();
        
        System.out.print("Password: ");
        String password = scanner.nextLine();
        
        User user = authService.login(username, password);
        
        if (user != null) {
            this.currentUser = user;
            System.out.println("\nWelcome, " + user.getUsername() + "!");
            System.out.println("Role: " + user.getRole());
            showUserMenu();
        } else {
            System.out.println("Login failed. Please check your credentials.");
        }
    }
    
    /**
     * Handle user registration
     */
    private void handleRegistration() {
        System.out.println("\n===== User Registration =====");
        
        System.out.print("Username: ");
        String username = scanner.nextLine();
        
        System.out.print("Email: ");
        String email = scanner.nextLine();
        
        System.out.print("Password: ");
        String password = scanner.nextLine();
        
        System.out.print("Confirm Password: ");
        String confirmPassword = scanner.nextLine();
        
        if (!password.equals(confirmPassword)) {
            System.out.println("Passwords do not match!");
            return;
        }
        
        System.out.print("Role (USER/ADMIN): ");
        String role = scanner.nextLine().toUpperCase();
        
        if (!role.equals("USER") && !role.equals("ADMIN")) {
            System.out.println("Invalid role. Defaulting to USER.");
            role = "USER";
        }
        
        boolean success = authService.registerUser(username, email, password, role);
        
        if (success) {
            System.out.println("Registration successful! You can now login.");
        } else {
            System.out.println("Registration failed. Please try again.");
        }
    }
    
    /**
     * Show menu for logged-in users
     */
    private void showUserMenu() {
        while (currentUser != null) {
            System.out.println("\n===== User Menu =====");
            System.out.println("1. View Profile");
            System.out.println("2. Change Password");
            System.out.println("3. Logout");
            
            if (currentUser.getRole().equals("ADMIN")) {
                System.out.println("4. Admin Panel");
            }
            
            System.out.print("Select an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline
            
            switch (choice) {
                case 1:
                    viewProfile();
                    break;
                case 2:
                    changePassword();
                    break;
                case 3:
                    logout();
                    return;
                case 4:
                    if (currentUser.getRole().equals("ADMIN")) {
                        showAdminPanel();
                    } else {
                        System.out.println("Invalid option.");
                    }
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
    
    /**
     * View current user profile
     */
    private void viewProfile() {
        System.out.println("\n===== User Profile =====");
        System.out.println("User ID: " + currentUser.getUserId());
        System.out.println("Username: " + currentUser.getUsername());
        System.out.println("Email: " + currentUser.getEmail());
        System.out.println("Role: " + currentUser.getRole());
        System.out.println("Status: " + (currentUser.isActive() ? "Active" : "Inactive"));
    }
    
    /**
     * Change password for current user
     */
    private void changePassword() {
        System.out.print("Current Password: ");
        String oldPassword = scanner.nextLine();
        
        System.out.print("New Password: ");
        String newPassword = scanner.nextLine();
        
        System.out.print("Confirm New Password: ");
        String confirmPassword = scanner.nextLine();
        
        if (!newPassword.equals(confirmPassword)) {
            System.out.println("Passwords do not match!");
            return;
        }
        
        boolean success = authService.changePassword(
            currentUser.getUsername(), 
            oldPassword, 
            newPassword
        );
        
        if (success) {
            System.out.println("Password changed successfully!");
        } else {
            System.out.println("Failed to change password.");
        }
    }
    
    /**
     * Logout current user
     */
    private void logout() {
        System.out.println("Logging out user: " + currentUser.getUsername());
        this.currentUser = null;
    }
    
    /**
     * Admin panel for user management
     */
    private void showAdminPanel() {
        System.out.println("\n===== Admin Panel =====");
        System.out.println("1. View All Users");
        System.out.println("2. Reset User Password");
        System.out.println("3. Back to User Menu");
        System.out.print("Select an option: ");
        
        int choice = scanner.nextInt();
        scanner.nextLine();
        
        switch (choice) {
            case 1:
                System.out.println("Admin feature: View all users");
                break;
            case 2:
                System.out.println("Admin feature: Reset password");
                break;
            case 3:
                return;
            default:
                System.out.println("Invalid option.");
        }
    }
    
    /**
     * Main entry point
     */
    public static void main(String[] args) {
        LoginController controller = new LoginController();
        controller.showMainMenu();
    }
}

